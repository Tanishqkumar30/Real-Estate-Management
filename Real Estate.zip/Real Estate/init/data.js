const sample=[{
    title:"rental",
    location:"indore",
    description:"by indore beach",
      price:120000,
    image:"",

},
{  
    title:"farm house",
location:"indore",
description:"3100sq ft,by indore beach",
  price:170000,
image:"",
},
{
 title:"plot/Land",
  location:"indore",
  description:"1500sq ft",
    price:170000,
  image:""

},
{
  title:"plot",
   location:"mhow",
   description:"800 sq ft",
     price:5100000,
   image:""
},
{
  title:"farm house",
   location:"indore",
   description:"5000sq ft",
     price:18000000,
   image:""
},
{title:"farm house",
   location:"indore",
   description:"4500sq ft",
     price:17000000,
   image:""
}, 
];

module.exports={data:sample};
