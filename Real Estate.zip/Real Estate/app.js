const express= require("express");
const app=express();

const port=8080;
const path=require("path");

 const Listing =require("./models/listing");
 const methodOverride = require("method-override");

const mongoose=require("mongoose");
const wrapAsync = require("./utils/wrapasync");
const listings =require("./routes/listing.js");
const Expresserr=require("./utils/expresserr");
const session=require("express-session");
const flash=require("connect-flash");

const passport=require("passport");
const Localstrategy=require("passport-local");
const userrouter=require("./routes/user.js");
const user=require("./models/usermodel.js");


main().then((res)=>{
    console.log(res);
})
.catch((err)=>{ console.log(err)});
async function main(){

   await mongoose.connect("mongodb://127.0.0.1:27017/data");
}

app.use(express.static(path.join(__dirname,"public")));

app.use(methodOverride("_method"));
app.use(express.urlencoded({extended:true}));
app.set("views", path.join(__dirname,"views"));
app.set("view engine","ejs");



const sessionoption={
    secret: "mynameistanishq",
    resave:false,
    saveUninitialized:true,
    cookie:{
        expires:Date.now()+7*24*60*60*1000,
        maxAge:7*24*60*60*1000,
        httponly:true,
    },
};

app.use(session(sessionoption));
app.use(flash());

app.use((req,res,next)=>{
         
 res.locals.message=req.flash("message");
 
 next();

})

//passport
app.use(passport.initialize());
app.use(passport.session());

passport.use(new Localstrategy(user.authenticate()));
passport.serializeUser(user.serializeUser());
passport.deserializeUser(user.deserializeUser());



app.use("/listings",listings);
app.use("/",userrouter);

app.all("*",(req,res,next)=>{

    next(new Expresserr(404,"page not  found"));
    
    });
   app.use((err,req,res,next)=>{
           
       let{status,message}=err;
         res.send(message);
    
        })
    




app.listen(port,()=>{
    console.log('http://localhost:8080/listings');
});