function isloogedin (req,res,next){

if(!req.isAuthenticated()){
    
    req.flash("error","you must be logged in");
   res.redirect("/listings");
   
    
}
    next();


};
module.exports=isloogedin;

module.exports.saveurl=(req,res,next)=>{
     if(req.session.redirecturl){

        res.locals.redirecturl=req.session.redirecturl;
     }
     next();
};