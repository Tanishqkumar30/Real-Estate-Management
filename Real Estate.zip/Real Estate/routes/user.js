const express=require("express");
const user = require("../models/usermodel");
const wrapAsync = require("../utils/wrapasync");
const passport = require("passport");
const router=express.Router();
const saveurl=require("../middleware.js")

router.get("/signup",(req,res)=>{
    res.render("user/signup.ejs");

});

router.post("/signup",wrapAsync(async(req,res)=>{
    try{
    let {username,email,password}=req.body;

    const newusr=new user({email,username});

    const regusr= await user.register(newusr,password);
    console.log(regusr);
    res.redirect("/login")
    }
    catch(err){
        res.redirect("/signup");
    }

}));

router.get("/login",(req,res)=>{
   res.render("user/login.ejs");
});

router.post("/login", passport.authenticate('local',{failureRedirect:"/login",failureFlash:true}),async(req,res)=>{
    // res.send("welcome to our Dream ESTATES</h1>");
    req.flash("message","welcome to dream estate");
    let redirect=res.locals.redirecturl || "/listings"

    res.redirect("/listings");    
});

router.get("/logout",(req,res,next)=>{

    req.logOut((err)=>{
        if(err){
            next(err);
        }
        req.flash("message","you logged out succeffuly");
        
        res.redirect("/listings")
    });
});

module.exports=router;