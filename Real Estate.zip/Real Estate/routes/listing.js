const express=require("express");
 const router=express.Router();
 const wrapAsync = require("../utils/wrapasync");
const listing = require("../models/listing");

const Listing =require("../models/listing");
const Expresserr=require("../utils/expresserr.js");
// const{listingschema}=require("../schema.js");
const isloogedin=require("../middleware.js");



 // new route
router.get("/new",isloogedin,(req,res)=>{

    res.render("new.ejs");
});


//show route

router.get("/:id", wrapAsync(async(req,res,next)=>{
 let {id}=req.params;

 const listing=await Listing.findById(id).populate("owner");
 res.render("show.ejs",{listing});

}));
//create route

router.post("/", isloogedin,wrapAsync(async (req,res,next)=>{
    
//   let result = listingschema.validate(req.body);
   newListing.owner=req.user._id;
 
   const newlist= new Listing(req.body.listing);
   await newlist.save();
   res.redirect("/listings"); 
}));


// edit 
router.get("/:id/edit",wrapAsync(async (req,res,next)=>{
     
let{id}=req.params;
const listing=await Listing.findById(id);
res.render("listings/edit.ejs",{listing});

}));

//update

router.put("/:id",wrapAsync(async(req,res)=>{
           
    let {id}=req.params;

      await Listing.findByIdAndUpdate(id,{...req.body.listing});

   res.redirect("/listings");

}));
//delete 

router.delete("/:id",wrapAsync(async(req,res,next)=>{

 let {id}=req.params;

 let deleted=await Listing.findByIdAndDelete(id);
 console.log("delete suuceful");
 res.redirect("/listings");
}));

//INDEX ROUTE

router.get("/",wrapAsync(async(req,res,next)=>{

   const allListings = await Listing.find({});
//  console.log(allListings);
  res.render("index.ejs",{allListings});

}));




module.exports=router;