// const joi=require("joi");

// module.exports.listingschema=joi.object({
//     listing:joi.object({
//         title:joi.string().required(),
//         location:joi.string().required(),
//         price:joi.number().required().min(30),
    
//     }).required(),
// });
